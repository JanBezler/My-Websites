<?php
	$host="";	//Adres phpmyadmin
	$db_user="";	//Login
	$db_password="";	//Hasło
	$db_name="";	//Nazwa bazy danych
?> 