<?php
	session_start();
	if(!isset($_SESSION['zalogowany']))
	{
		header('Location:index.php');
		exit();
	}
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
	<style>body{background-color:aaaaaa;}</style>
	<title>Logowanie</title>
</head>
<body>

<?php

	echo "<p>Witaj ".$_SESSION['user'].'!'.'  [<a href="logout.php">Wyloguj</a>]';
	
	echo "<p><b>E-mail</b>: ".$_SESSION['email'];
	
	
	/* Premium
	$dataczas=new DateTime();
	$koniec = DateTime::createFromFormat('Y-m-d H:i:s',$_SESSION['dnipremium']);
	$roznica = $dataczas->diff($koniec);
	
	if($dataczas<$koniec)
		echo "Pozostało premium: ".$roznica->format('%d dni %h godz %i min');
	else echo"Premium nieaktywne od: ".$roznica->format('%Y lat %m mies %d dni %h godz %i min');
	*/
?>


</body>
</html>