<?php
session_start();

	if(!isset($_SESSION['udanarejestracja']))
		{
		header('Location:pliki.php');
		exit();
		}
		else unset($_SESSION['udanarejestracja']);	
		
		//usuwamy zmienne pamiętanych wartości do formularza
		if(isset($_SESSION['fr_nick'])) unset($_SESSION['fr_nick']);
		if(isset($_SESSION['fr_email'])) unset($_SESSION['fr_email']);
		if(isset($_SESSION['fr_pass1'])) unset($_SESSION['fr_pass1']);
		if(isset($_SESSION['fr_pass2'])) unset($_SESSION['fr_pass2']);
		if(isset($_SESSION['fr_regulami'])) unset($_SESSION['fr_nregulamin']);
		//usuwamy błędy rejestracji
		if(isset($_SESSION['e_nick'])) unset($_SESSION['e_nick']);
		if(isset($_SESSION['e_email'])) unset($_SESSION['e_email']);
		if(isset($_SESSION['e_haslo']) )unset($_SESSION['e_haslo']);
		if(isset($_SESSION['e_regulamin'])) unset($_SESSION['e_regulamin']);
		if(isset($_SESSION['e_bot'])) unset($_SESSION['e_bot']);
?>
<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8"/>
	<title></title>
	<meta name="description" content="Logout"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
</head>
<body>

			<div>
				<a href="pliki.php"><input type="button" value="Powrót na stronę logowania"/></a>
			</div>
</body>
</html>